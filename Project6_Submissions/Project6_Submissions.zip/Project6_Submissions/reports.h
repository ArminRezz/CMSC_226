// invmenu.h
#pragma once

#include <iostream>
#include <cctype>
#include <iomanip>

using namespace std; 

void reports();
void handleUserChoice();
void repListing();
void repWholesale();
void repRetail();
void repQty();
void repCost();
void repAge();
void selectionSort(double[]);
void selectionSort(int[]);
void printTotal(double[]);  
