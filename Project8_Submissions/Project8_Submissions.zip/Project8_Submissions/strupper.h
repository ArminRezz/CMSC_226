void strUpper(char*);
