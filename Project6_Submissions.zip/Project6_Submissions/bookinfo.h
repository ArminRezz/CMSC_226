#pragma once
#include <iostream>
#include <string>
#include <cctype> 

using namespace std; 

void bookInfo(char[], char[], char[], char[], char[], int, double, double);