#ifndef CASH_H
#define CASH_H

#include <iostream>
#include <iomanip>
using namespace std;

//prototypes
void cashier();

#endif