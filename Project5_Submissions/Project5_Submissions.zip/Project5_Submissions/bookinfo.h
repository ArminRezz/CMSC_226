#pragma once
#include <iostream>
#include <string>

using namespace std; 

void bookInfo(string, string, string, string, string, int, double, double);