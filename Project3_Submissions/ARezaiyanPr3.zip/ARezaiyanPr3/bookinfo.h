// invmenu.h
#include <string>
#pragma once

using namespace std; 

class Bookinfo
{
    public:
    void bookInfo();
};
