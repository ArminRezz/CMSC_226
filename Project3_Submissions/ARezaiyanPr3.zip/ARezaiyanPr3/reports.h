// invmenu.h
#include <string>
#pragma once

using namespace std; 
class Reports
{
    public:
        void reports();
        void handleUserChoice();
        void repListing();
        void repWholesale();
        void repRetail();
        void repQty();
        void repCost();
        void repAge();
};

