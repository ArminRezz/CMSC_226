#ifndef REPORTS_H
#define REPORTS_H

#include <iostream>
#include <iomanip>
using namespace std;

//prototypes
void report();
void repListing();
void repWholesale();
void repRetail();
void repQty();
void repCost();
void repAge();

#endif