#ifndef MAIN_H
#define MAIN_H

#include <iostream>
#include <iomanip>
#include <cctype>

void printMenu();

#endif