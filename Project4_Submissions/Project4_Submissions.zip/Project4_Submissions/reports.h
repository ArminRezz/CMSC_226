// invmenu.h
#pragma once

#include <iostream>
using namespace std; 

void reports();
void handleUserChoice();
void repListing();
void repWholesale();
void repRetail();
void repQty();
void repCost();
void repAge();

