// cashier.h
#pragma once

#include <iostream>
#include <iomanip>

using namespace std; 

void cashier();
void displayTicket();
double calcSubTotal();
double calcSalesTax();
double calculateTotal();
